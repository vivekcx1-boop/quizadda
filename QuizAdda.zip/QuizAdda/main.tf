terraform {
  required_providers {
    azurerm = {
      source  = "hashicorp/azurerm"
      version = "~>3.0"
    }
  }
}

provider "azurerm" {
  features {}
}

resource "azurerm_resource_group" "quizadda_rg" {
  name     = "quizadda-rg"
  location = "East US 2"
}

resource "azurerm_static_web_app" "quizadda_site" {
  name                = "quizadda-vivek123"
  resource_group_name = azurerm_resource_group.quizadda_rg.name
  location            = azurerm_resource_group.quizadda_rg.location
  sku_tier            = "Free"
  sku_size            = "Free"
}